'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = _interopDefault(require('react'));

/**
 * Returns a function, that, as long as it continues to be invoked, will not
 * be triggered. The function will be called after it stops being called for
 * N milliseconds. If `immediate` is passed, trigger the function on the
 * leading edge, instead of the trailing. The function also has a property 'clear' 
 * that is a function which will clear the timer to prevent previously scheduled executions. 
 *
 * @source underscore.js
 * @see http://unscriptable.com/2009/03/20/debouncing-javascript-methods/
 * @param {Function} function to wrap
 * @param {Number} timeout in ms (`100`)
 * @param {Boolean} whether to execute at the beginning (`false`)
 * @api public
 */
function debounce(func, wait, immediate){
  var timeout, args, context, timestamp, result;
  if (null == wait) wait = 100;

  function later() {
    var last = Date.now() - timestamp;

    if (last < wait && last >= 0) {
      timeout = setTimeout(later, wait - last);
    } else {
      timeout = null;
      if (!immediate) {
        result = func.apply(context, args);
        context = args = null;
      }
    }
  }
  var debounced = function(){
    context = this;
    args = arguments;
    timestamp = Date.now();
    var callNow = immediate && !timeout;
    if (!timeout) timeout = setTimeout(later, wait);
    if (callNow) {
      result = func.apply(context, args);
      context = args = null;
    }

    return result;
  };

  debounced.clear = function() {
    if (timeout) {
      clearTimeout(timeout);
      timeout = null;
    }
  };
  
  debounced.flush = function() {
    if (timeout) {
      result = func.apply(context, args);
      context = args = null;
      
      clearTimeout(timeout);
      timeout = null;
    }
  };

  return debounced;
}
// Adds compatibility for ES modules
debounce.debounce = debounce;

var debounce_1 = debounce;

function getScrollY(ref) {
    return (ref ? ref.pageYOffset || ref.scrollTop : null) || 0;
}
function defaultTrigger(event, store, deps) {
    var _a = deps[0], disableHysteresis = _a === void 0 ? true : _a, _b = deps[1], threshold = _b === void 0 ? 100 : _b;
    var previous = store.current;
    store.current = getScrollY(event && event.currentTarget);
    if (disableHysteresis) {
        if (store.current < previous) {
            return false;
        }
        return store.current > previous && store.current > threshold;
    }
    return store.current > threshold;
}
var defaultTarget = typeof window !== 'undefined' ? window : null;
function useDebounce(handler, debounceProp) {
    return debounceProp ? debounce_1(handler, 166) : handler; // 166 corresponds to 10 frames at 60 Hz.
}
function useEventTrigger(props, deps) {
    if (props === void 0) { props = {}; }
    var _a = props.event, event = _a === void 0 ? 'scroll' : _a, _b = props.getTrigger, getTrigger = _b === void 0 ? defaultTrigger : _b, _c = props.debounce, debounce = _c === void 0 ? true : _c, _d = props.target, target = _d === void 0 ? defaultTarget : _d;
    var store = React.useRef();
    var _e = React.useState(function () { return getTrigger(null, store, deps); }), trigger = _e[0], setTrigger = _e[1];
    React.useEffect(function () {
        var handleEvent = useDebounce(function (event) {
            setTrigger(getTrigger(event, store, deps));
        }, debounce);
        target.addEventListener(event, handleEvent);
        return function () {
            target.removeEventListener(event, handleEvent);
            debounce && handleEvent.clear();
        };
    }, [target, getTrigger].concat(deps));
    return [trigger, store];
}

/**
 * @class ExampleComponent
 */

exports.default = useEventTrigger;
//# sourceMappingURL=index.js.map
